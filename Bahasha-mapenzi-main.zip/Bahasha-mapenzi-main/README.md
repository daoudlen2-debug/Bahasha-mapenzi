# Bahasha-mapenzi
Ir is aimed at the romantic love message
